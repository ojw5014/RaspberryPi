#!/bin/bash
sudo g++ -o test0 test0.cpp COjw_37_Protocol2.cpp COjw_37_Protocol2.h -lpthread -lwiringPi
sudo ./test0